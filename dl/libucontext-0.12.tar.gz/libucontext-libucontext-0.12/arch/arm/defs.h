#ifndef __ARCH_ARM_DEFS_H

#define REG_SZ		(4)
#define MCONTEXT_GREGS	(32)

#define TYPE(__proc)

#include "common-defs.h"

#endif
