#!/bin/sh

autoreconf --install --verbose
